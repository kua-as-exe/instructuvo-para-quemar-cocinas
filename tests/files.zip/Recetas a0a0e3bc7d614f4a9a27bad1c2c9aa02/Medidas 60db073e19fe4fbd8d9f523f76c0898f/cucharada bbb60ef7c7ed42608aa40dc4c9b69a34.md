# cucharada

g: 15