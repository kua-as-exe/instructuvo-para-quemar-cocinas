# consomé de pollo

Calorías: 16
Carbohidrato: 0.38
Grasas: 0.57
Potasio: 0.086
Proteina: 2.02
Sodio: 0.318
gramos: 100