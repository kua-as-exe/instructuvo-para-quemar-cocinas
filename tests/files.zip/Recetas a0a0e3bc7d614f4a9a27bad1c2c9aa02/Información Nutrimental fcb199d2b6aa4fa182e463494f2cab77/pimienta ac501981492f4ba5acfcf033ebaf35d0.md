# pimienta

Agua: 12.46
Calorías: 251
Carbohidrato: 64
Fibra: 25.3
Proteina: 10.39
Sodio: 0.02
gramos: 100