# epazote

Agua: 89.21
Calorías: 32
Carbohidrato: 7.4
Grasas: 0.52
Por: (g): 100
Proteina: 0.36
Sodio: 0.043