# mantequilla

Agua: 15.87
Calorías: 717
Carbohidrato: 0.1
Sodio: 0.643
gramos: 100