# mantequilla

Agua: 15.87
Calorías: 717
Carbohidrato: 0.1
Por: (g): 100
Sodio: 0.643