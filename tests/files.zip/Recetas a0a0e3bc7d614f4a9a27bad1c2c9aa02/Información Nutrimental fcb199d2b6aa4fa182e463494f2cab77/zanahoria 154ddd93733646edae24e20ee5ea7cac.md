# zanahoria

Azucar: 4.74
Calorías: 41
Carbohidrato: 9.6
Fibra: 2.8
Por: (g): 100