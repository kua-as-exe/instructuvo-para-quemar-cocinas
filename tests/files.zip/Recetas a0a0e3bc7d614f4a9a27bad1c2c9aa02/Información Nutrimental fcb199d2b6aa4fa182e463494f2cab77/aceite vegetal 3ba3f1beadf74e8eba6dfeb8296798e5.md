# aceite vegetal

Calorías: 120
Grasas: 13.6
Por: (g): 15