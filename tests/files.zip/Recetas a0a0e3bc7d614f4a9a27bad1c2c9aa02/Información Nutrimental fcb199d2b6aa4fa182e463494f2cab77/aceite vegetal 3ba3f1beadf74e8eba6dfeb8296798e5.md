# aceite vegetal

Calorías: 120
Grasas: 13.6
gramos: 15