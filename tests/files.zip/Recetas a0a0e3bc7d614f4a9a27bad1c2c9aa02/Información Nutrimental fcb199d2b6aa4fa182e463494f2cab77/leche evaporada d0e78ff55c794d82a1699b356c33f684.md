# leche evaporada

Azucar: 10.6
Calcio: 0.261
Calorías: 121
Grasas: 4.5
Por: (g): 100
Proteina: 5.6
Sodio: 0.125