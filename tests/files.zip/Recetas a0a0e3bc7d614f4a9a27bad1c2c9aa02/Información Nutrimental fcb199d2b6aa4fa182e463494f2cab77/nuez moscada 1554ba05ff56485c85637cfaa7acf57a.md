# nuez moscada

Agua: 6.23
Azucar: 2.99
Calorías: 525
Carbohidrato: 49.3
Fibra: 20.8
Proteina: 5.84
Sodio: 0.016
gramos: 100