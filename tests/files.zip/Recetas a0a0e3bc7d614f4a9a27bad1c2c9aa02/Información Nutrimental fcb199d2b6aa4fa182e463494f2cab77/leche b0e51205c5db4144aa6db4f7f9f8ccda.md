# leche

Calorías: 156
Carbohidrato: 11.03
Grasas: 7.93
Proteina: 7.86
gramos: 250