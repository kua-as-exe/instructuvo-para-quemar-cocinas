# Untitled

Texto: Antes de cocinar lee las recetas completamente, asegúrate de tener todos los ingredientes
Url: https://media.giphy.com/media/BSsSBKN1eKGUU/giphy.gif