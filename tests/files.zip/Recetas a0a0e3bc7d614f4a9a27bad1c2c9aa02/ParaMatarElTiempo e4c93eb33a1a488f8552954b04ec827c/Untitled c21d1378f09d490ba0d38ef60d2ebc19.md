# Untitled

Texto: Amasa, amasa, amasa, amasa, vuelve a amasar, amasa otra vez, una vez más...
Url: https://media.giphy.com/media/O5hoOqZtdwzoQ/giphy.gif