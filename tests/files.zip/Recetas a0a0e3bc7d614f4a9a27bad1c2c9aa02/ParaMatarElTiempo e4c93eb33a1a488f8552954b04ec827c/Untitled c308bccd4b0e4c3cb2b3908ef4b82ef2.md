# Untitled

Texto: La práctica hace al maestro
Url: https://media.giphy.com/media/3o85g3loeiLcF26OZy/giphy.gif