# Untitled

Texto: No olvides apagar la estufa cuando termines de cocinar
Url: https://media.giphy.com/media/12lL9jqB0Ogx2w/giphy.gif