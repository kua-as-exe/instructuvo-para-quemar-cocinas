# Untitled

Texto: Una olla no define tu cocina
Url: https://media.giphy.com/media/xT1Ra4CM74LvQVs4mI/giphy.gif