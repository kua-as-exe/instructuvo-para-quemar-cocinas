# Galletas de limón

Autor: Elisabet Juarez
Descripción: Unas deliciosas galletas sabor limón, crujientes que se le antojarán a cualquiera
Lito: Yes
Personas: 10
Tags: Galletas, Harina, Limón, Postre
TiempoAprox: 20-25 minutos

## Ingredientes

- 3/4 de taza de mantequilla a temperatura ambiente
- 1/4 de taza de azúcar glass
- 129g de leche condensada
- 3 cucharadas de zumo de limón
- 1 cucharada de ralladura de limón
- 3 1/6 tazas de harina
- 2 cucharaditas de polvo para hornear

## Modo de preparación

1. Cremar la mantequilla con el azúcar
2. Agregar la leche condensada el zumo de limón y la ralladura y mezclar
3. Cernir la harina con el polvo para hornear
4. Incorporar en 4 partes la harina con el polvo para hornear y mezclar
5. En una superficie plana colocar un poco de harina espolvoreada y la masa
6. Con un rodillo con harina o un vaso aplanar la masa hasta unos 4 cm de grosor
7. Cortar círculos o con cortadores las formas de las galletas, siendo del mismo grosor y tamaño
8. En una bandeja colocar papel encerado y las galletas separadas
9. En un horno previamente calentado, a 175º hornear por 20 minutos cuando la orilla de las galletas esté dorada

## Información nutricional

- 

---

> ⌛ Tiempo de preparación 20-25 minutos

> 🥞 Capacidad 10 personas

## Tips

>