# Crema de zanahoria

Created: Nov 13, 2020 6:13 PM
Lito: Yes

## Ingredientes

- 9 zanahorias (900g aproximadamente)
- 1/2 taza de leche
- 2 tazas de agua
- 18g de consomé de pollo
- 1/2 cucharadita de pimienta*
- 1/4 cucharadita de nuez moscada*
- 1/3 taza de leche condensada*

## Modo de preparación

1. Lavar y pelar las zanahorias
2. Cortar las zanahorias en trozos chicos-medianos
3. Colocar las zanahorias en una olla mediana y cubrir las zanahorias con agua potable
4. Hervir hasta que las zanahorias esten suaves
5. Licuar las zanahorias con su agua, junto con la leche o leche condensada*, la pimienta*, la nuez moscada* y el consomé de pollo
6. Hervir nuevamente y servir

## Información nutricional

- 900*g*zanahoria
- 1/2*taza*leche
- 18*g*consomé de pollo
- 〰1/2*cucharadita*pimienta
- 〰1/4*cucharadita*nuez moscada
- 〰1/3*taza*leche condensada

---

> ⌛  Tiempo de preparación 15-20 minutos

> 🧇  Capacidad 4-6 personas

## Tips

> 🔆 Licuar 2 veces para evitar grumos
🔆 Para verificar si están suaves, al insertar un tenedor en ellas sea sencillo
🔆 Para convertirla en sopa sustituir la leche por agua