# Tortitas de carne

Autor: Elisabet Juarez
Descripción: Para una hamburguesa, para una comida, de varios tamaños y haciéndola sencilla
Lito: Yes
Personas: 8
Tags: Carne, Hamburguesa, Zanahoria
TiempoAprox: 30 minutos

## Ingredientes

- 1/4 de cebolla (25g aproximadamente)
- 2 huevos (112g aproximadamente)
- 500g de pan molido
- 1 cucharadita de sal
- 1 cucharadita de pimienta
- 4 zanahorias (400g aproximadamente)
- 1 cucharada de mostaza
- 500g de carne molida

## Modo de preparación

1. Pelar y rayar las zanahorias
2. Licuar la cebolla, mostaza, sal, pimienta, y los huevos
3. En un bowl poner la carne molida y agregar la mezcla, revolver
4. Agregar el pan molido en 3 partes
5. Agregar las zanahorias en 3 partes
6. Hacer bolitas y aplastarlas en forma de tortilla, no deben de estar delgadas, para evitar que se quemen
7. En un sartén colocar el aceite y las tortitas, dependiendo del tamaño de la sartén y el tamaño de las tortitas, se podrán colocar de 2-6 tortitas
8. Freir las tortitas esperando que las orillas de la tortilla estén doradas para voltearla
9. En un plato ir colocardo las tortitas y servir

## Información nutricional

- 

---

> ⌛ Tiempo de preparación: 30 minutos

> 🥞 Capacidad: 8 personas

## Tips

> 🔆 En el plato poner servilletas al ir colocando las tortitas para absorber el exceso de grasa.