# Tortitas de carne

Created: Nov 15, 2020 12:09 AM
Lito: No

## Ingredientes

- 
- 1/4 de cebolla
- 2 huevos

    Dependerá del tamaño

- 1/2 kilo de pan molido
- 1 cucharadita de sal
- 1 cucharadita de pimienta

    Sin moler

- 4 zanahorias
- 1 cucharada de mostaza
- 1/2 kilo de carne molida

## Modo de preparación

1. 
2. Pelar las zanahoriasy rayarlas
3. Licuar la cebolla, la mostaza, la sal y los huevos
4. En un bowl poner la carne molida y agregar la mezcla, revolver
5. Agregar el pan molido en 3 partes
6. Agregar las zanahorias en 3 partes
7. Hacer bolitas y aplastarlas en forma de tortilla, no deben de estar delgadas, para eitar que se quemen
8. En un sarté colocar el aceite y las tortitas de poco en poco, dependiendo del tamaño de la sartén y el tamaño de las tortitas, se podrán colocar de 2-6 tortitas
9. Freir las tortitas esperando que las orillas de la tortilla estén doradas para voltearla
10. En un plato ir colocardo las tortitas y servir

## Información nutricional

- 

---

> Tiempo de preparación: 30 minutos

> Capacidad: 8 personas

## Tips

> En el plato poner servilletas al ir colocando las tortitas para absorber el exceso de grasa.