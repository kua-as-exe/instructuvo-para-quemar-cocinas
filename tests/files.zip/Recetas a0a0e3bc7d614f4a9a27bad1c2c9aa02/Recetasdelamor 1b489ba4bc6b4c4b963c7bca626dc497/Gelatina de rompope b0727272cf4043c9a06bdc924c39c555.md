# Gelatina de rompope

Autor: Elisabet Juarez
Descripción: Un postre frío en ocasiones especiales
Lito: Yes
Personas: 12
Tags: Alcohol, Frío, Gelatina, Postre, Rompope
TiempoAprox: 15-20 minutos

## Ingredientes

- 387g de rompope
- 387g de leche condensada
- 370g de leche evaporada
- 3 cucharadas de grenetina
- 225g de media crema
- 1/2 taza de agua

## Modo de preparación

1. Licúa o bate el rompope junto con la leche condensada, la leche evaporada y la media crema
2. En una taza vierte el agua y agrega las 3 cucharadas de grenetina
3. Lleva a microondas por intervalos de 7 segundos vigilando que no escurra la grenetina, hasta que no queden grumos
4. Vertir la grenetina con la mezcla anterior y batir o licuar
5. Vertir en un molde y dejar enfriar de 3-4 horas 

## Información nutricional

- 

---

> ⌛ Tiempo de preparación 15-20 minutos

> 🥞 Capacidad 12 personas

## Tips

>