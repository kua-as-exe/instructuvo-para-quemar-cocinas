# Tortilla española

Autor: Elisabet Juarez
Descripción: De España a tu mesa, un platillo a base de huevo y papas que te quitará el hambre
Lito: Yes
Personas: 6
Tags: Caliente, Huevo, Papas, Pimiento
TiempoAprox: 30-40 minutos

## Ingredientes

- 3 papas (500g aproximadamente)
- 1 pimiento (150g aproximadamente)
- 7 huevos (392g aproximadamente)
- 1 cebolla (100 gramos aproximadamente)
- 4 cucharaditas de sal

## Modo de preparación

1. Asar los pimientos con 1 cucharadita de sal y después quitarles la cáscara
2. Lavar las papas, pelarlas y cortarlas en tiras
3. Lavar la cebolla y cortarla en cuadritos
4. Freir las papas junto con la cebolla y el resro de la sal, cocer sin que se doren las papas
5. Batir los huevos y revolverlos con los pimientos
6. Vaciar los huevos con kos pimientos en las papas en un sartén con fuego medio bajo
7. Deja cocer y voltea la tortilla con cuidado hasta que cueza completamente el huevo 

## Información nutricional

- 

---

> ⌛ Tiempo de preparación 34- 40 minutos

> 🥞 Capacidad 6 personas

## Tips

>