# Tortilla española

Autor: Elisabet Juárez
Lito: No
TiempoAprox: [30,40]minutos

## Ingredientes

- 3 papas (500g aproximadamente)
- 1 pimiento (150g aproximadamente)
- 7 huevos (392g aproximadamente)
- 1 cebolla (100 gramos aproximadamente)

## Modo de preparación

1. Asar los pimientos con sal y después quitarles la cáscara
2. 

## Información nutricional

- 

---

> ⌛ Tiempo de preparación 34- 40 minutos

> 🥞 Capacidad 6 personas

## Tips

>