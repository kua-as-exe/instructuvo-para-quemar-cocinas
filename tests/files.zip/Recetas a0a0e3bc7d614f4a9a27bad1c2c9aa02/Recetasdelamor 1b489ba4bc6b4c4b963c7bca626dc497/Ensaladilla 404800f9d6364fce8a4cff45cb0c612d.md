# Ensaladilla

Autor: Elisabet Juarez
Descripción: Una pequeña porción de un sabor intenso que con torta o con tortilla de ensalada te puedes llenar y saciar tu apetito
Lito: Yes
Personas: 8
Tags: Aceitunas, Ajo, Ensalada, Huevo, Papas, Pimiento
TiempoAprox: 40 minutos

## Ingredientes

- 3 papas (500g aproximadamente)
- 2 huevos (112g aproximadamente)
- 4 cucharadas de mayonesa
- 1/5 de cebolla
- 1 lata de atún (140g)
- 1 pimiento morrón (150g aproximadamente)
- 2 cucharaditas de sal
- 1/2taza de chicharos
- 1 paquete de aceitunas (175g)
- 4 dientes de ajo (45g aproximadamente)

## Modo de preparación

1. Hervir las papas, los chicharos y los huevos 
2. Asar el pimiento morrón con sal y retirarle la cáscara
3. Quitarle la cáscara a las papas y machacarlas y agregar el atún
4. Quitarle la cáscara a los huevos, separar la yema de la clara y partir las claras en cuadros
5. Partir en rodajas las aceitunas
6. Pelar los ajos y partirlos en cuadritos
7. Partir la cebolla en cuadritos
8. A la mezcla de las papas con el atún agregar los chícharos, las aceitunas, los ajos, la cebolla, el pimiento morrón, las claras de huevo y mezclar
9. Desmoronar las yemas
10. Aplanar la mezcla y poner encima las yemas desmoronadas

## Información nutricional

- 

---

> ⌛ Tiempo de preparación 40 minutos

> 🥞 Capacidad 8 personas

## Tips

>