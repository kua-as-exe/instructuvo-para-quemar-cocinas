# Caldo de papas

Autor: Elisabet Juárez
Lito: Yes

## Ingredientes

- 3 papas (500g)
- 1/5 de cebolla (20g aproximadamente)
- 4 tazas de caldo de pollo
- 1 rama de epazote (10g)
- 18g de consomé de pollo disueltos en 4 tazas de agua*

## Modo de preparación

1. Lavar las papas
2. Pelar y cortar las papas en tiras
3. Freir en un sartén poner el aceite con la cebolla y las papas
4. En una olla poner a hervir las papas previamente freidas con el caldo de pollo y la rama de epazote
5. Dejar hervir por unos 20 minutos y servir

## Información nutricional

- 

---

> ⌛ Tiempo de preparación: 25-30 minutos

> 🥞 Capacidad: 6 personas

## Tips

> 🔆 Para agregar un picor incorpora a la sopa 1 chipotle con cebolla previamente fritos al momento de hervir