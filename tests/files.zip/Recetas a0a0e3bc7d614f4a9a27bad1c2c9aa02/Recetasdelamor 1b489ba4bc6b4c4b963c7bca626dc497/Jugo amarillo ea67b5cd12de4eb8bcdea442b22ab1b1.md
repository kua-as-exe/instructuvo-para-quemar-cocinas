# Jugo amarillo

Autor: Elisabet Juarez
Descripción: Un poco de nutrientes harán bien para tu digestión y es una buena forma de empezar tu mañana
Lito: Yes
Personas: 4
Tags: Apio, Guayaba, Jugo, Miel, Piña
TiempoAprox: 10-12 minutos

## Ingredientes

- 4 guayabas (449.2g aproximadamente)
- 1/5 de piña (100g aproximadamente)
- 2 ramas de apio (200g aproximadamente)
- 4 cucharadas de miel

## Modo de preparación

1. Quitarle la cáscara de la piña y cortarla en pedazos
2. Lavar las guayabas y el apio
3. Cortar al apio a partir de donde comiezan las ramificaciones y utilizar sólo el tallo
4. Cortar en mitades las guayabas, en cubos la piña y el pedazos chicos-medianos el apio
5. Vaciar en una licuadora con 1 taza de agua y agregar la miel
6. Licuar

## Información nutricional

- 

---

> ⌛ Tiempo de preparación 10-12 minutos

> 🥞 Capacidad 4 personas

## Tips

> 🔆 Si el jugo es muy espeso agregar 1 taza de agua