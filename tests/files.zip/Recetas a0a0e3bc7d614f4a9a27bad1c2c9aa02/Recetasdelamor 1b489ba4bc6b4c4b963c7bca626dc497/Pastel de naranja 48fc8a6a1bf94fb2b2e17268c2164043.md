# Pastel de naranja

Autor: Elisabet Juárez
Lito: Yes
Tags: Pastel

## Ingredientes

- 1 taza de mantequilla
- 6 huevos (324g aproximadamente)
- 1 lata de leche condensada (370g)
- 2 cucharadas de ralladura de naranja
- 2 1/4 tazas de harina
- 1 1/2 cucharaditas de polvo para hornear

## Modo de preparación

1. Separar las yemas de las claras de los huevos
2. Batir las yemas con la mantequilla hasta acremar
3. Añadir la leche condensada y la ralladura de naranja
4. Cernir la harina y el polvo para hornear e incorporare de poco en poco a la masa
5. Batir las claras hasta punto turrón
6. Añadir las claras a la mezcla de forma envolvente, delas orillas hacia el centro
7. En grasar y enharinar un molde, embarrando mantequilla y espolvoreando harina
8. Vaciar la mezcla en el molde y meterla en un horno previamente precalentado a 200 grados por 40 minutos o hasta que el palillo salga limpio

## Información nutricional

- 

---

> ⌛ Tiempo de preparación 1 hora 15 minutos aproximadamente

> 🥞 Capacidad 10 personas

## Tips

> 🔆 En vez de enharinar el molde con mantequilla y harina se puede usar aceite en spry