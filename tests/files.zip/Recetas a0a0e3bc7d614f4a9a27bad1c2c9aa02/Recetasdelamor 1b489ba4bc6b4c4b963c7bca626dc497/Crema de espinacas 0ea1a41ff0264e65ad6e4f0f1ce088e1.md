# Crema de espinacas

Autor: Elisabet Juárez
Lito: Yes

## Ingredientes

- 1 cucharada de mantequilla
- 4 ramas de espinacas (80g aproximadamente)
- 1/5 de cebolla (20g aproximadamente)
- 2 tazas de agua
- 1 taza de leche
- 1/3 de taza de leche evaporada

## Modo de preparación

1. Separar las hojas de las espinacas, lavarlas
2. Lavar y cortar la cebolla en pedazos medianos
3. En una olla poner la mantequilla, la cebolla y las espinacas a fuego medio
4. Cocer las espinacas, moviendolos regularmente hasta que se forma una pequeña bola de espinacas
5. Licuar las espinacas junto con la cebolla con el agua y laleche o leche condensada*
6. Hervir la mezcla nuevamente y servir

## Información nutricional

- 

---

> ⌛ Tiempo de preparación de 15-20 minutos

> 🥞 Capacidad 6 personas

## Tips

> 🔆 Para hacer la sopa más espesa en la olla coloca la mantequilla con una cucharada de fécula de maiz a fuego bajo hasta que haga burbujas y seguir con el procedimiento
🔆 Para convertir en sopa sustituir la leche por agua